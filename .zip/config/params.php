<?php

return [
    'adminEmail' => 'admin@example.com',
    'passwordResetTokenExpire'=> '86400',
    'page_title'=> 'Social Leaders',
    'from_mail'=> 'banelasainath@gmail.com',
];
